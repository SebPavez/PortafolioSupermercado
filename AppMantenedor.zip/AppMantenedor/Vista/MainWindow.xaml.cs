﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Vista
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void image_Loaded(object sender, RoutedEventArgs e)
        {
            BitmapImage imagen = new BitmapImage();
            imagen.BeginInit();            

            imagen.UriSource = new Uri(@"c://imagenes/veguita.png");
            imagen.EndInit();

            var image = sender as Image;
            image.Source = imagen;
        }

        private void btnIngresar_Click(object sender, RoutedEventArgs e)
        {   //TODO
            //instanciar objeto usuario, llamar a método autenticar, y esperar resultado booleano
            //si es true, acceder a ventana principal y cerrar actual, de lo contrario, mostrar MessageBox
            if (true) {
                this.Close();
            }
            else {
                MessageBox.Show("datos de usuario inválidos");
            }
        }
    }
}
